create function st_closestpoint(text, text) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_ClosestPoint($1::public.geometry, $2::public.geometry);  $$;

alter function st_closestpoint(text, text) owner to postgres;

